
<?php
// Arquivo: sos4/api/conexao.php
// ...
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', ''); 

// 🚨 CORREÇÃO AQUI: DEVE SER EXATAMENTE O NOME QUE VOCÊ CRIOU!
define('DB_NAME', 'sosamazonia'); 

// Tentativa de conexão com o banco de dados MySQL
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Verificar conexão
if($conn->connect_error){
    die("ERRO: Não foi possível conectar ao banco de dados: " . $conn->connect_error);
}
// ...
?>