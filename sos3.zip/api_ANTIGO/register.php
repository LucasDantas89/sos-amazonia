<?php
// Arquivo: sos4/api/register.php

// 1. Inclui o arquivo que faz a conexão com o banco de dados
require_once 'conexao.php'; 

// Verifica se a requisição é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 2. Recebe os dados JSON do seu JavaScript
    $data = json_decode(file_get_contents("php://input"));

    if (empty($data->name) || empty($data->email) || empty($data->password)) {
        http_response_code(400); // Bad Request
        echo json_encode(["success" => false, "message" => "Todos os campos são obrigatórios."]);
        exit();
    }

    $name = $conn->real_escape_string($data->name);
    $email = $conn->real_escape_string($data->email);
    $password = $data->password;

    // 3. CRIA HASH SEGURO DA SENHA (ESSENCIAL PARA SEGURANÇA)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // 4. Verifica se o e-mail já existe
    $check_sql = "SELECT id FROM sosamazonia WHERE email = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        http_response_code(409); // Conflict
        echo json_encode(["success" => false, "message" => "Este e-mail já está cadastrado."]);
        $stmt->close();
        exit();
    }
    $stmt->close();
    
    // 5. Insere o novo usuário no banco de dados
    
    $stmt = $conn->prepare($insert_sql);
    $insert_sql = "INSERT INTO sosamazonia (name, email, password) VALUES (?, ?, ?)";
    if ($stmt->bind_param("sss", $name, $email, $hashed_password) && $stmt->execute()) {
        http_response_code(201); // Created
        echo json_encode(["success" => true, "message" => "Cadastro realizado com sucesso!"]);
    } else {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Erro ao salvar o usuário: " . $conn->error]);
    }

    $stmt->close();
    $conn->close();

} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["success" => false, "message" => "Método não permitido."]);
}
?>